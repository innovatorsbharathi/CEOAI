package com.ceoai.face;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * CEO AI — Local HTTP Expression API Server
 *
 * Starts a lightweight HTTP server on port 8765.
 * Other devices / processes on the same network can POST
 * to change the robot's facial expression.
 *
 * ─── API REFERENCE ───────────────────────────────────────────────────────────
 *
 *  POST /expression
 *  Content-Type: application/json
 *  Body: { "expression": "happy" }
 *
 *  Valid values: neutral | happy | thinking | alert | angry
 *
 *  GET /expression
 *  Returns: { "expression": "neutral", "status": "ok" }
 *
 *  GET /health
 *  Returns: { "status": "ok", "agent": "CEO AI Face v1.0" }
 *
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *  Example curl commands (run from another device on same WiFi):
 *
 *    curl -X POST http://<TABLET_IP>:8765/expression \
 *         -H "Content-Type: application/json" \
 *         -d '{"expression":"happy"}'
 *
 *    curl http://<TABLET_IP>:8765/health
 *
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class ExpressionApiServer {

    private static final String TAG  = "CEOAIFaceAPI";
    public  static final int    PORT = 8765;

    private ServerSocket      mServerSocket;
    private ExecutorService   mExecutor;
    private volatile boolean  mRunning = false;
    private ExpressionListener mListener;

    // ── Callback interface ────────────────────────────────────────────────────
    public interface ExpressionListener {
        void onExpressionCommand(int expression);
    }

    public ExpressionApiServer(ExpressionListener listener) {
        mListener = listener;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void start() {
        if (mRunning) return;
        mRunning  = true;
        mExecutor = Executors.newCachedThreadPool();

        mExecutor.submit(() -> {
            try {
                mServerSocket = new ServerSocket(PORT);
                Log.i(TAG, "CEO AI Face API listening on port " + PORT);

                while (mRunning) {
                    try {
                        Socket client = mServerSocket.accept();
                        mExecutor.submit(() -> handleRequest(client));
                    } catch (Exception e) {
                        if (mRunning) Log.w(TAG, "Accept error: " + e.getMessage());
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Server start failed: " + e.getMessage());
            }
        });
    }

    public void stop() {
        mRunning = false;
        try {
            if (mServerSocket != null) mServerSocket.close();
        } catch (Exception e) { /* ignore */ }
        if (mExecutor != null) mExecutor.shutdownNow();
        Log.i(TAG, "CEO AI Face API stopped");
    }

    // ── Request handler ───────────────────────────────────────────────────────

    private void handleRequest(Socket client) {
        try (
            BufferedReader in  = new BufferedReader(new InputStreamReader(client.getInputStream()));
            OutputStream   out = client.getOutputStream()
        ) {
            // Read request line + headers
            String requestLine = in.readLine();
            if (requestLine == null) return;

            Log.d(TAG, "Request: " + requestLine);

            String[] parts  = requestLine.split(" ");
            String   method = parts.length > 0 ? parts[0] : "";
            String   path   = parts.length > 1 ? parts[1] : "/";

            // Read headers
            int    contentLength = 0;
            String line;
            while ((line = in.readLine()) != null && !line.isEmpty()) {
                if (line.toLowerCase().startsWith("content-length:")) {
                    contentLength = Integer.parseInt(line.split(":")[1].trim());
                }
            }

            // Dispatch
            String body   = "";
            String response;

            if ("GET".equalsIgnoreCase(method) && path.startsWith("/health")) {
                response = jsonOk("{\"status\":\"ok\",\"agent\":\"CEO AI Face v1.0\",\"port\":" + PORT + "}");

            } else if ("GET".equalsIgnoreCase(method) && path.startsWith("/expression")) {
                // Current expression name returned by MainActivity
                String name = ExpressionNameHelper.getName(getCurrentExpression());
                response = jsonOk("{\"expression\":\"" + name + "\",\"status\":\"ok\"}");

            } else if ("POST".equalsIgnoreCase(method) && path.startsWith("/expression")) {
                // Read body
                if (contentLength > 0) {
                    char[] buf = new char[contentLength];
                    in.read(buf, 0, contentLength);
                    body = new String(buf);
                }
                int exprCode = parseExpression(body);
                if (exprCode >= 0) {
                    if (mListener != null) mListener.onExpressionCommand(exprCode);
                    String name = ExpressionNameHelper.getName(exprCode);
                    response = jsonOk("{\"status\":\"ok\",\"expression\":\"" + name + "\"}");
                } else {
                    response = jsonError(400, "Unknown expression. Valid: neutral|happy|thinking|alert|angry");
                }

            } else {
                response = jsonError(404, "Not found. Endpoints: GET /health, GET /expression, POST /expression");
            }

            out.write(response.getBytes(StandardCharsets.UTF_8));
            out.flush();

        } catch (Exception e) {
            Log.w(TAG, "Request handling error: " + e.getMessage());
        } finally {
            try { client.close(); } catch (Exception e) { /* ignore */ }
        }
    }

    // ── JSON helpers ──────────────────────────────────────────────────────────

    private String jsonOk(String body) {
        return "HTTP/1.1 200 OK\r\n"
             + "Content-Type: application/json\r\n"
             + "Access-Control-Allow-Origin: *\r\n"
             + "Connection: close\r\n\r\n"
             + body;
    }

    private String jsonError(int code, String message) {
        String status = code == 400 ? "Bad Request" : "Not Found";
        return "HTTP/1.1 " + code + " " + status + "\r\n"
             + "Content-Type: application/json\r\n"
             + "Access-Control-Allow-Origin: *\r\n"
             + "Connection: close\r\n\r\n"
             + "{\"status\":\"error\",\"message\":\"" + message + "\"}";
    }

    // ── Expression parsing ────────────────────────────────────────────────────

    private int parseExpression(String json) {
        if (json == null) return -1;
        String lower = json.toLowerCase();
        if (lower.contains("neutral"))  return FaceView.EXPRESSION_NEUTRAL;
        if (lower.contains("happy"))    return FaceView.EXPRESSION_HAPPY;
        if (lower.contains("thinking")) return FaceView.EXPRESSION_THINKING;
        if (lower.contains("alert"))    return FaceView.EXPRESSION_ALERT;
        if (lower.contains("angry"))    return FaceView.EXPRESSION_ANGRY;
        return -1;
    }

    // ── State bridge (set by MainActivity) ───────────────────────────────────
    private int mCurrentExpression = FaceView.EXPRESSION_NEUTRAL;
    public void setCurrentExpression(int e) { mCurrentExpression = e; }
    private int getCurrentExpression()      { return mCurrentExpression; }
}
