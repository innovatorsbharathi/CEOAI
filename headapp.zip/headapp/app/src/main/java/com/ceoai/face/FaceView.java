package com.ceoai.face;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/**
 * CEO AI — Executive Face Renderer
 *
 * Design language: authoritative, precise, cold intelligence.
 * Inspired by high-end HUD displays and industrial control panels.
 *
 * Face structure:
 *   - Circular head plate with concentric ring detail
 *   - Wide horizontal visor-lens (like an executive visor / Iron Man slit)
 *   - Thin, decisive mouth indicator
 *   - Outer targeting ring with tick marks
 *   - Data readout strips at bottom of face
 *
 * Expressions communicate intent through precise geometry:
 *   NEUTRAL   — steady visor glow, balanced tick marks, flat mouth
 *   HAPPY     — visor brightens and widens, subtle uptick corners
 *   THINKING  — visor splits into two focused analysis beams, ring rotates
 *   ALERT     — rapid concentric pulse rings, visor blazes amber
 *   ANGRY     — visor contracts to a narrow slit, heavy inward brow lines
 */
public class FaceView extends View {

    // ── Expression constants ──────────────────────────────────────────────────
    public static final int EXPRESSION_NEUTRAL  = 0;
    public static final int EXPRESSION_HAPPY    = 1;
    public static final int EXPRESSION_THINKING = 2;
    public static final int EXPRESSION_ALERT    = 3;
    public static final int EXPRESSION_ANGRY    = 4;

    // ── State ─────────────────────────────────────────────────────────────────
    private int   mCurrentExpression = EXPRESSION_NEUTRAL;
    private int   mTargetExpression  = EXPRESSION_NEUTRAL;
    private float mTransition        = 1f;
    private float mPulse             = 0f;   // 0→1 oscillation for all expressions
    private float mScanAngle         = 0f;   // thinking ring rotation degrees
    private float mAlertRing         = 0f;   // alert expanding ring phase (0→1)
    private float mBlinkProgress     = 1f;   // 1 = visor fully open, 0 = closed

    // ── Animators ─────────────────────────────────────────────────────────────
    private ValueAnimator mPulseAnimator;
    private ValueAnimator mScanAnimator;
    private ValueAnimator mAlertAnimator;
    private ValueAnimator mBlinkAnimator;
    private ValueAnimator mTransitionAnimator;

    // ── Paints ────────────────────────────────────────────────────────────────
    private final Paint mFillPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mRingPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mVisorPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mLinePaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mGlowPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mTickPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ── Colour palette — cold intelligence ───────────────────────────────────
    private static final int COL_BG        = Color.parseColor("#080c10");
    private static final int COL_FACE_FILL = Color.parseColor("#0d1520");
    private static final int COL_NEUTRAL   = Color.parseColor("#4a9eff");
    private static final int COL_HAPPY     = Color.parseColor("#00d4a8");
    private static final int COL_THINKING  = Color.parseColor("#9b7fff");
    private static final int COL_ALERT     = Color.parseColor("#ff8c00");
    private static final int COL_ANGRY     = Color.parseColor("#cc1a1a");

    // ── Geometry helpers ──────────────────────────────────────────────────────
    private final RectF mFaceRect  = new RectF();
    private final Path  mPath      = new Path();

    public FaceView(Context ctx) { this(ctx, null); }
    public FaceView(Context ctx, AttributeSet attrs) {
        super(ctx, attrs);
        initPaints();
        startPulseAnimator();
        scheduleNextBlink();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    public int getExpression() { return mCurrentExpression; }

    public void setExpression(int expr) {
        if (expr == mTargetExpression && mTransition >= 1f) return;
        mTargetExpression = expr;
        if (mTransitionAnimator != null) mTransitionAnimator.cancel();
        mTransitionAnimator = ValueAnimator.ofFloat(0f, 1f);
        mTransitionAnimator.setDuration(700);
        mTransitionAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        mTransitionAnimator.addUpdateListener(a -> {
            mTransition = (float) a.getAnimatedValue();
            if (mTransition >= 1f) mCurrentExpression = mTargetExpression;
            invalidate();
        });
        mTransitionAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                mCurrentExpression = mTargetExpression;
                mTransition = 1f;
                updateExpressionAnimators();
            }
        });
        mTransitionAnimator.start();
        updateExpressionAnimators();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Main draw
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float W  = getWidth(), H = getHeight();
        float cx = W / 2f,    cy = H / 2f;
        float faceR = Math.min(W, H) * 0.38f;

        int activeExpr  = mTransition < 0.5f ? mCurrentExpression : mTargetExpression;
        int activeColor = blendColor(mCurrentExpression, mTargetExpression, mTransition);

        mFaceRect.set(cx - faceR, cy - faceR, cx + faceR, cy + faceR);

        // ── 1. Background ────────────────────────────────────────────────────
        canvas.drawColor(COL_BG);
        drawBackground(canvas, W, H, cx, cy, activeColor);

        // ── 2. Alert expanding rings ─────────────────────────────────────────
        if (activeExpr == EXPRESSION_ALERT) {
            drawAlertRings(canvas, cx, cy, faceR, activeColor);
        }

        // ── 3. Targeting ring with ticks ─────────────────────────────────────
        drawTargetingRing(canvas, cx, cy, faceR, activeColor, activeExpr);

        // ── 4. Face disc ─────────────────────────────────────────────────────
        drawFaceDisc(canvas, cx, cy, faceR, activeColor, activeExpr);

        // ── 5. Visor ─────────────────────────────────────────────────────────
        drawVisor(canvas, cx, cy, faceR, activeColor, activeExpr);

        // ── 6. Brow lines ────────────────────────────────────────────────────
        drawBrows(canvas, cx, cy, faceR, activeColor, activeExpr);

        // ── 7. Mouth indicator ───────────────────────────────────────────────
        drawMouth(canvas, cx, cy, faceR, activeColor, activeExpr);

        // ── 8. Data strips ───────────────────────────────────────────────────
        drawDataStrips(canvas, cx, cy, faceR, activeColor, activeExpr);

        // ── 9. Thinking analysis arc ─────────────────────────────────────────
        if (activeExpr == EXPRESSION_THINKING) {
            drawThinkingArc(canvas, cx, cy, faceR, activeColor);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Draw helpers
    // ─────────────────────────────────────────────────────────────────────────

    private void drawBackground(Canvas canvas, float W, float H,
                                float cx, float cy, int color) {
        // Subtle horizontal scan lines
        Paint scanLine = new Paint();
        scanLine.setColor(Color.argb(10, 80, 140, 220));
        scanLine.setStrokeWidth(1f);
        for (float y = 0; y < H; y += dp(12)) {
            canvas.drawLine(0, y, W, y, scanLine);
        }
        // Central ambient glow
        Paint radial = new Paint(Paint.ANTI_ALIAS_FLAG);
        radial.setShader(new RadialGradient(cx, cy, Math.min(W, H) * 0.5f,
                Color.argb(22, Color.red(color), Color.green(color), Color.blue(color)),
                Color.TRANSPARENT, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, W, H, radial);
    }

    private void drawAlertRings(Canvas canvas, float cx, float cy,
                                float faceR, int color) {
        mGlowPaint.setStyle(Paint.Style.STROKE);
        mGlowPaint.setMaskFilter(null);
        for (int i = 0; i < 3; i++) {
            float phase  = (mAlertRing + i * 0.333f) % 1f;
            float ringR  = faceR * (1.05f + phase * 0.55f);
            float alphaf = 1f - phase;
            mGlowPaint.setColor(color);
            mGlowPaint.setAlpha((int)(150 * alphaf));
            mGlowPaint.setStrokeWidth(dp(2f) * alphaf);
            canvas.drawCircle(cx, cy, ringR, mGlowPaint);
        }
    }

    private void drawTargetingRing(Canvas canvas, float cx, float cy,
                                   float faceR, int color, int expr) {
        float outerR = faceR * 1.17f;

        int saved = canvas.save();
        if (expr == EXPRESSION_THINKING) canvas.rotate(mScanAngle, cx, cy);

        // Main ring
        mRingPaint.setColor(color);
        mRingPaint.setAlpha(55);
        mRingPaint.setStyle(Paint.Style.STROKE);
        mRingPaint.setStrokeWidth(dp(1.5f));
        canvas.drawCircle(cx, cy, outerR, mRingPaint);

        // Tick marks
        mTickPaint.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 24; i++) {
            double angle    = Math.toRadians(i * 15.0);
            boolean major   = (i % 6 == 0);
            float   tickLen = major ? dp(11f) : dp(4f);
            mTickPaint.setColor(color);
            mTickPaint.setAlpha(major ? 210 : 70);
            mTickPaint.setStrokeWidth(major ? dp(2.5f) : dp(1.5f));
            mTickPaint.setStrokeCap(Paint.Cap.SQUARE);
            float s = (float) Math.sin(angle);
            float c2 = (float) Math.cos(angle);
            canvas.drawLine(cx + s * outerR,            cy - c2 * outerR,
                            cx + s * (outerR - tickLen), cy - c2 * (outerR - tickLen),
                            mTickPaint);
        }
        canvas.restoreToCount(saved);

        // Inner subtle ring
        mRingPaint.setAlpha(25);
        mRingPaint.setStrokeWidth(dp(1f));
        canvas.drawCircle(cx, cy, faceR * 1.06f, mRingPaint);
    }

    private void drawFaceDisc(Canvas canvas, float cx, float cy,
                              float faceR, int color, int expr) {
        // Outer glow
        mGlowPaint.setColor(color);
        int glowAlpha = expr == EXPRESSION_ALERT
                ? (int)(45 + 35 * mPulse)
                : (int)(20 + 10 * mPulse);
        mGlowPaint.setAlpha(glowAlpha);
        mGlowPaint.setStyle(Paint.Style.STROKE);
        mGlowPaint.setStrokeWidth(dp(18));
        mGlowPaint.setMaskFilter(new android.graphics.BlurMaskFilter(
                dp(22), android.graphics.BlurMaskFilter.Blur.NORMAL));
        canvas.drawCircle(cx, cy, faceR, mGlowPaint);
        mGlowPaint.setMaskFilter(null);

        // Fill
        mFillPaint.setColor(COL_FACE_FILL);
        mFillPaint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(cx, cy, faceR, mFillPaint);

        // Rim
        mRingPaint.setColor(color);
        mRingPaint.setAlpha(190);
        mRingPaint.setStrokeWidth(dp(2.5f));
        canvas.drawCircle(cx, cy, faceR, mRingPaint);

        // Inner detail ring
        mRingPaint.setAlpha(35);
        mRingPaint.setStrokeWidth(dp(1f));
        canvas.drawCircle(cx, cy, faceR * 0.87f, mRingPaint);
    }

    /**
     * Visor — the primary "eye": a wide horizontal band.
     * Height communicates mood. No cartoon eyes — this is a machine.
     */
    private void drawVisor(Canvas canvas, float cx, float cy,
                           float faceR, int color, int expr) {
        float visorCY = cy - faceR * 0.16f;
        float visorW  = faceR * 1.30f;   // clipped by face circle below

        float heightFactor;
        switch (expr) {
            case EXPRESSION_HAPPY:    heightFactor = 0.22f; break;
            case EXPRESSION_ALERT:    heightFactor = 0.20f + 0.04f * mPulse; break;
            case EXPRESSION_ANGRY:    heightFactor = 0.065f; break;
            case EXPRESSION_THINKING: heightFactor = 0.10f;  break;
            default:                  heightFactor = 0.15f;
        }
        float halfH = faceR * heightFactor * mBlinkProgress;

        if (expr == EXPRESSION_THINKING) {
            // Two separate focused beams
            float beamW = faceR * 0.44f;
            float gap   = faceR * 0.20f;
            drawVisorBeam(canvas, cx - gap - beamW, visorCY, beamW, halfH, color, expr);
            drawVisorBeam(canvas, cx + gap,          visorCY, beamW, halfH, color, expr);
        } else {
            // Single unified visor — clip to face interior
            float clipR  = faceR * 0.90f;
            float left   = cx - visorW / 2f;
            float right  = cx + visorW / 2f;
            // Chord clipping: find x where circle intersects visor top/bottom
            float chordY = Math.abs(visorCY - cy);
            if (chordY < clipR) {
                float halfChord = (float) Math.sqrt(clipR * clipR - chordY * chordY);
                left  = Math.max(left,  cx - halfChord);
                right = Math.min(right, cx + halfChord);
            }
            drawVisorBeam(canvas, left, visorCY, right - left, halfH, color, expr);
        }
    }

    private void drawVisorBeam(Canvas canvas, float left, float centerY,
                               float beamW, float halfH, int color, int expr) {
        RectF r      = new RectF(left, centerY - halfH, left + beamW, centerY + halfH);
        float corner = Math.max(halfH * 0.25f, dp(2f));

        // Fill
        mVisorPaint.setColor(color);
        int fillA = 35;
        if (expr == EXPRESSION_ALERT) fillA = (int)(55 + 45 * mPulse);
        if (expr == EXPRESSION_ANGRY) fillA = 70;
        if (expr == EXPRESSION_HAPPY) fillA = 50;
        mVisorPaint.setAlpha(fillA);
        mVisorPaint.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(r, corner, corner, mVisorPaint);

        // Stroke
        mVisorPaint.setAlpha(230);
        mVisorPaint.setStyle(Paint.Style.STROKE);
        mVisorPaint.setStrokeWidth(dp(expr == EXPRESSION_ANGRY ? 3f : 2f));
        canvas.drawRoundRect(r, corner, corner, mVisorPaint);

        // Center horizontal depth line (lens effect)
        if (halfH > dp(5)) {
            mVisorPaint.setAlpha(55);
            mVisorPaint.setStrokeWidth(dp(1f));
            canvas.drawLine(left + dp(8), centerY, left + beamW - dp(8), centerY, mVisorPaint);
        }

        // White specular highlight on top edge
        if (expr != EXPRESSION_ANGRY) {
            mLinePaint.setColor(Color.WHITE);
            mLinePaint.setAlpha(35);
            mLinePaint.setStrokeWidth(dp(1f));
            mLinePaint.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawLine(left + corner * 2, r.top + dp(1.5f),
                            left + beamW - corner * 2, r.top + dp(1.5f), mLinePaint);
        }
    }

    /**
     * Brow lines — horizontal structural lines above the visor.
     * Precise and intentional. No cartoon arches — just lines and angles.
     */
    private void drawBrows(Canvas canvas, float cx, float cy,
                           float faceR, int color, int expr) {
        if (expr == EXPRESSION_HAPPY) return;  // open expression — no brows needed

        float browW = faceR * 0.34f;
        float gap   = faceR * 0.18f;
        float browY = cy - faceR * 0.40f;

        mLinePaint.setColor(color);
        mLinePaint.setStyle(Paint.Style.STROKE);
        mLinePaint.setStrokeCap(Paint.Cap.SQUARE);

        switch (expr) {
            case EXPRESSION_NEUTRAL:
                mLinePaint.setStrokeWidth(dp(3f));
                mLinePaint.setAlpha(150);
                canvas.drawLine(cx - gap - browW, browY, cx - gap, browY, mLinePaint);
                canvas.drawLine(cx + gap,         browY, cx + gap + browW, browY, mLinePaint);
                break;

            case EXPRESSION_THINKING:
                // Asymmetric — one raised, one angled
                mLinePaint.setStrokeWidth(dp(2.5f));
                mLinePaint.setAlpha(190);
                canvas.drawLine(cx - gap - browW, browY - dp(9), cx - gap, browY - dp(1), mLinePaint);
                mLinePaint.setAlpha(120);
                canvas.drawLine(cx + gap, browY + dp(3), cx + gap + browW, browY - dp(1), mLinePaint);
                break;

            case EXPRESSION_ALERT:
                float alertBrowY = cy - faceR * 0.37f;
                mLinePaint.setStrokeWidth(dp(4f));
                mLinePaint.setAlpha((int)(190 + 60 * mPulse));
                canvas.drawLine(cx - gap - browW, alertBrowY, cx - gap, alertBrowY, mLinePaint);
                canvas.drawLine(cx + gap,         alertBrowY, cx + gap + browW, alertBrowY, mLinePaint);
                // Second line — high alert double brow
                mLinePaint.setStrokeWidth(dp(1.5f));
                mLinePaint.setAlpha(75);
                canvas.drawLine(cx - gap - browW, alertBrowY - dp(8), cx - gap, alertBrowY - dp(8), mLinePaint);
                canvas.drawLine(cx + gap, alertBrowY - dp(8), cx + gap + browW, alertBrowY - dp(8), mLinePaint);
                break;

            case EXPRESSION_ANGRY:
                // Heavy inward V — no ambiguity
                float angryBrowY = cy - faceR * 0.38f;
                mLinePaint.setStrokeWidth(dp(4.5f));
                mLinePaint.setAlpha(255);
                canvas.drawLine(cx - gap - browW, angryBrowY - dp(13),
                                cx - gap,          angryBrowY + dp(5), mLinePaint);
                canvas.drawLine(cx + gap,          angryBrowY + dp(5),
                                cx + gap + browW,  angryBrowY - dp(13), mLinePaint);
                break;
        }
    }

    /**
     * Mouth — precise line indicator. Not expressive in a human way.
     * Changes denote operational mode, not emotion.
     */
    private void drawMouth(Canvas canvas, float cx, float cy,
                           float faceR, int color, int expr) {
        float mouthY = cy + faceR * 0.42f;
        float mouthW = faceR * 0.50f;

        mLinePaint.setColor(color);
        mLinePaint.setStyle(Paint.Style.STROKE);
        mLinePaint.setStrokeCap(Paint.Cap.SQUARE);
        mLinePaint.setAlpha(190);

        switch (expr) {
            case EXPRESSION_NEUTRAL:
                mLinePaint.setStrokeWidth(dp(2.5f));
                canvas.drawLine(cx - mouthW / 2f, mouthY, cx + mouthW / 2f, mouthY, mLinePaint);
                // End caps
                mLinePaint.setAlpha(100);
                mLinePaint.setStrokeWidth(dp(2f));
                canvas.drawLine(cx - mouthW / 2f, mouthY - dp(4), cx - mouthW / 2f, mouthY + dp(4), mLinePaint);
                canvas.drawLine(cx + mouthW / 2f, mouthY - dp(4), cx + mouthW / 2f, mouthY + dp(4), mLinePaint);
                break;

            case EXPRESSION_HAPPY:
                // Main line + angled upticks at ends — restrained satisfaction
                mLinePaint.setStrokeWidth(dp(2.5f));
                float innerW = mouthW * 0.55f;
                canvas.drawLine(cx - innerW / 2f, mouthY, cx + innerW / 2f, mouthY, mLinePaint);
                mLinePaint.setAlpha(150);
                canvas.drawLine(cx - mouthW / 2f, mouthY, cx - innerW / 2f, mouthY - dp(6), mLinePaint);
                canvas.drawLine(cx + innerW / 2f, mouthY - dp(6), cx + mouthW / 2f, mouthY, mLinePaint);
                break;

            case EXPRESSION_THINKING:
                // Off-center angled line — asymmetric analysis
                mLinePaint.setStrokeWidth(dp(2f));
                mLinePaint.setAlpha(155);
                canvas.drawLine(cx - mouthW * 0.28f, mouthY + dp(4),
                                cx + mouthW * 0.48f, mouthY - dp(4), mLinePaint);
                break;

            case EXPRESSION_ALERT:
                // Double parallel lines — heightened state
                mLinePaint.setStrokeWidth(dp(3f));
                mLinePaint.setAlpha((int)(190 + 60 * mPulse));
                canvas.drawLine(cx - mouthW / 2f, mouthY - dp(3), cx + mouthW / 2f, mouthY - dp(3), mLinePaint);
                mLinePaint.setStrokeWidth(dp(1.5f));
                mLinePaint.setAlpha(95);
                canvas.drawLine(cx - mouthW * 0.38f, mouthY + dp(5), cx + mouthW * 0.38f, mouthY + dp(5), mLinePaint);
                break;

            case EXPRESSION_ANGRY:
                // Short, heavy, pushed down — rejection
                mLinePaint.setStrokeWidth(dp(4.5f));
                mLinePaint.setAlpha(255);
                float angryY = cy + faceR * 0.50f;
                canvas.drawLine(cx - mouthW * 0.32f, angryY, cx + mouthW * 0.32f, angryY, mLinePaint);
                break;
        }
    }

    /** Three data-readout bars — the face has live status indicators */
    private void drawDataStrips(Canvas canvas, float cx, float cy,
                                float faceR, int color, int expr) {
        float baseY  = cy + faceR * 0.62f;
        float stripW = faceR * 0.52f;
        float stripH = dp(3f);
        float gap    = dp(7.5f);

        float[] fills = dataFills(expr);

        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setStyle(Paint.Style.FILL);

        for (int i = 0; i < 3; i++) {
            float y = baseY + i * (stripH + gap);
            float x = cx - stripW / 2f;

            // Track
            bg.setColor(Color.parseColor("#141e2e"));
            bg.setAlpha(255);
            canvas.drawRoundRect(new RectF(x, y, x + stripW, y + stripH),
                    stripH / 2f, stripH / 2f, bg);

            // Fill
            bg.setColor(color);
            float fill = (i == 0 && expr == EXPRESSION_ALERT)
                    ? 0.45f + 0.55f * mPulse : fills[i];
            int alpha = i == 0 ? 210 : (i == 1 ? 145 : 85);
            bg.setAlpha(alpha);
            canvas.drawRoundRect(new RectF(x, y, x + stripW * fill, y + stripH),
                    stripH / 2f, stripH / 2f, bg);
        }
    }

    /** Rotating dashed analysis arc for THINKING */
    private void drawThinkingArc(Canvas canvas, float cx, float cy,
                                 float faceR, int color) {
        float arcR = faceR * 1.27f;
        RectF oval = new RectF(cx - arcR, cy - arcR, cx + arcR, cy + arcR);
        mLinePaint.setStyle(Paint.Style.STROKE);
        mLinePaint.setStrokeCap(Paint.Cap.ROUND);
        mLinePaint.setStrokeWidth(dp(3f));

        float base = mScanAngle;
        for (int i = 0; i < 6; i++) {
            float start = base + i * 40f;
            mLinePaint.setColor(color);
            mLinePaint.setAlpha(i % 2 == 0 ? 175 : 45);
            canvas.drawArc(oval, start, 22f, false, mLinePaint);
        }
        // Counter-static arc
        mLinePaint.setAlpha(50);
        mLinePaint.setStrokeWidth(dp(1.5f));
        canvas.drawArc(oval, base + 180f, 35f, false, mLinePaint);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Colour & data helpers
    // ─────────────────────────────────────────────────────────────────────────

    private int exprColor(int e) {
        switch (e) {
            case EXPRESSION_HAPPY:    return COL_HAPPY;
            case EXPRESSION_THINKING: return COL_THINKING;
            case EXPRESSION_ALERT:    return COL_ALERT;
            case EXPRESSION_ANGRY:    return COL_ANGRY;
            default:                  return COL_NEUTRAL;
        }
    }

    private int blendColor(int from, int to, float t) {
        int a = exprColor(from), b = exprColor(to);
        return Color.rgb(
            (int)(Color.red(a)   + (Color.red(b)   - Color.red(a))   * t),
            (int)(Color.green(a) + (Color.green(b) - Color.green(a)) * t),
            (int)(Color.blue(a)  + (Color.blue(b)  - Color.blue(a))  * t)
        );
    }

    private float[] dataFills(int expr) {
        switch (expr) {
            case EXPRESSION_HAPPY:    return new float[]{0.93f, 0.87f, 0.79f};
            case EXPRESSION_THINKING: return new float[]{0.52f, 0.36f, 0.64f};
            case EXPRESSION_ALERT:    return new float[]{0.80f, 0.62f, 0.91f};
            case EXPRESSION_ANGRY:    return new float[]{0.25f, 0.15f, 0.08f};
            default:                  return new float[]{0.65f, 0.50f, 0.38f};
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Paint initialisation
    // ─────────────────────────────────────────────────────────────────────────

    private void initPaints() {
        mFillPaint.setStyle(Paint.Style.FILL);
        mRingPaint.setStyle(Paint.Style.STROKE);
        mVisorPaint.setAntiAlias(true);
        mVisorPaint.setStrokeCap(Paint.Cap.ROUND);
        mVisorPaint.setStrokeJoin(Paint.Join.ROUND);
        mLinePaint.setAntiAlias(true);
        mLinePaint.setStrokeCap(Paint.Cap.BUTT);
        mLinePaint.setStrokeJoin(Paint.Join.MITER);
        mGlowPaint.setStyle(Paint.Style.STROKE);
        mTickPaint.setStyle(Paint.Style.STROKE);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Animators
    // ─────────────────────────────────────────────────────────────────────────

    private void startPulseAnimator() {
        mPulseAnimator = ValueAnimator.ofFloat(0f, 1f);
        mPulseAnimator.setDuration(2200);
        mPulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        mPulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        mPulseAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        mPulseAnimator.addUpdateListener(a -> {
            mPulse = (float) a.getAnimatedValue();
            invalidate();
        });
        mPulseAnimator.start();
    }

    private void scheduleNextBlink() {
        postDelayed(() -> {
            mBlinkAnimator = ValueAnimator.ofFloat(1f, 0.04f, 1f);
            mBlinkAnimator.setDuration(300);
            mBlinkAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
            mBlinkAnimator.addUpdateListener(a -> {
                mBlinkProgress = (float) a.getAnimatedValue();
                invalidate();
            });
            mBlinkAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator a) {
                    scheduleNextBlink();
                }
            });
            mBlinkAnimator.start();
        }, 4500L + (long)(Math.random() * 3000L));
    }

    private void updateExpressionAnimators() {
        stopExpressionAnimators();

        if (mTargetExpression == EXPRESSION_THINKING) {
            mScanAnimator = ValueAnimator.ofFloat(0f, 360f);
            mScanAnimator.setDuration(7000);
            mScanAnimator.setRepeatCount(ValueAnimator.INFINITE);
            mScanAnimator.setInterpolator(new LinearInterpolator());
            mScanAnimator.addUpdateListener(a -> {
                mScanAngle = (float) a.getAnimatedValue();
                invalidate();
            });
            mScanAnimator.start();
        }

        if (mTargetExpression == EXPRESSION_ALERT) {
            mAlertAnimator = ValueAnimator.ofFloat(0f, 1f);
            mAlertAnimator.setDuration(950);
            mAlertAnimator.setRepeatCount(ValueAnimator.INFINITE);
            mAlertAnimator.setInterpolator(new LinearInterpolator());
            mAlertAnimator.addUpdateListener(a -> {
                mAlertRing = (float) a.getAnimatedValue();
                invalidate();
            });
            mAlertAnimator.start();
        }
    }

    private void stopExpressionAnimators() {
        if (mScanAnimator  != null) { mScanAnimator.cancel();  mScanAnimator  = null; }
        if (mAlertAnimator != null) { mAlertAnimator.cancel(); mAlertAnimator = null; }
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
