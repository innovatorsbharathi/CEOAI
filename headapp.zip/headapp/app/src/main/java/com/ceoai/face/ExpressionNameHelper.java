package com.ceoai.face;

/**
 * Utility — maps expression int codes ↔ human-readable names.
 */
public class ExpressionNameHelper {

    public static String getName(int expression) {
        switch (expression) {
            case FaceView.EXPRESSION_HAPPY:    return "happy";
            case FaceView.EXPRESSION_THINKING: return "thinking";
            case FaceView.EXPRESSION_ALERT:    return "alert";
            case FaceView.EXPRESSION_ANGRY:    return "angry";
            default:                           return "neutral";
        }
    }

    public static String getLabel(int expression) {
        switch (expression) {
            case FaceView.EXPRESSION_HAPPY:    return "HAPPY";
            case FaceView.EXPRESSION_THINKING: return "THINKING";
            case FaceView.EXPRESSION_ALERT:    return "ALERT";
            case FaceView.EXPRESSION_ANGRY:    return "ANGRY";
            default:                           return "NEUTRAL";
        }
    }

    public static int[] getAll() {
        return new int[]{
            FaceView.EXPRESSION_NEUTRAL,
            FaceView.EXPRESSION_HAPPY,
            FaceView.EXPRESSION_THINKING,
            FaceView.EXPRESSION_ALERT,
            FaceView.EXPRESSION_ANGRY
        };
    }
}
