package com.ceoai.face;

import android.app.Activity;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

/**
 * CEO AI — Main Activity
 *
 * Full-screen immersive face display for a 9" Android tablet.
 *
 * Layout (programmatic — no XML needed):
 *   ┌─────────────────────────────────────────────────┐
 *   │                  FaceView (full)                 │
 *   │                                                  │
 *   │   [expression label]       [IP:PORT overlay]     │
 *   └─────────────────────────────────────────────────┘
 */
public class MainActivity extends Activity
        implements AutoCycleManager.OnExpressionChange,
                   ExpressionApiServer.ExpressionListener {

    private static final String TAG = "CEOAIFace";

    // ── Views ─────────────────────────────────────────────────────────────────
    private FaceView  mFaceView;
    private TextView  mExpressionLabel;
    private TextView  mIpLabel;
    private TextView  mApiStatusDot;

    // ── Controllers ───────────────────────────────────────────────────────────
    private AutoCycleManager    mCycleManager;
    private ExpressionApiServer mApiServer;
    private final Handler       mUiHandler = new Handler(Looper.getMainLooper());

    // ── API-override flash state ──────────────────────────────────────────────
    private boolean mApiFlashActive = false;

    // ─────────────────────────────────────────────────────────────────────────
    // Lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full-screen, keep screen on
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                           | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
              | View.SYSTEM_UI_FLAG_FULLSCREEN
              | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
              | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
              | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
              | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );

        buildLayout();

        // Start auto-cycle (5 sec per expression)
        mCycleManager = new AutoCycleManager(this, 5_000);
        mCycleManager.start();

        // Start HTTP API server
        mApiServer = new ExpressionApiServer(this);
        mApiServer.start();

        // Show IP after a short delay (needs time to get IP)
        mUiHandler.postDelayed(this::refreshIpLabel, 800);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mCycleManager.stop();
        mApiServer.stop();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Layout (programmatic — avoids needing XML for a self-contained project)
    // ─────────────────────────────────────────────────────────────────────────

    private void buildLayout() {
        // Root: FrameLayout so overlays float on top of FaceView
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0d1117"));

        // ── Face view (fill parent) ───────────────────────────────────────────
        mFaceView = new FaceView(this);
        root.addView(mFaceView, new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT));

        // ── Bottom overlay bar ────────────────────────────────────────────────
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(20), dp(10), dp(20), dp(10));
        bar.setBackgroundColor(Color.parseColor("#99010409"));

        // Expression name label (left)
        mExpressionLabel = new TextView(this);
        mExpressionLabel.setTextColor(Color.parseColor("#3b82f6"));
        mExpressionLabel.setTextSize(11f);
        mExpressionLabel.setTypeface(android.graphics.Typeface.MONOSPACE,
                android.graphics.Typeface.BOLD);
        mExpressionLabel.setText("◆ NEUTRAL");
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        bar.addView(mExpressionLabel, labelParams);

        // API status dot (center)
        mApiStatusDot = new TextView(this);
        mApiStatusDot.setTextSize(10f);
        mApiStatusDot.setTextColor(Color.parseColor("#22c55e"));
        mApiStatusDot.setTypeface(android.graphics.Typeface.MONOSPACE);
        mApiStatusDot.setText("● API");
        mApiStatusDot.setPadding(dp(8), 0, dp(8), 0);
        bar.addView(mApiStatusDot);

        // IP label (right)
        mIpLabel = new TextView(this);
        mIpLabel.setTextColor(Color.parseColor("#4b5563"));
        mIpLabel.setTextSize(10f);
        mIpLabel.setTypeface(android.graphics.Typeface.MONOSPACE);
        mIpLabel.setText("…:8765");
        bar.addView(mIpLabel);

        android.widget.FrameLayout.LayoutParams barParams =
                new android.widget.FrameLayout.LayoutParams(
                        android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                        android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
        barParams.gravity = android.view.Gravity.BOTTOM;
        root.addView(bar, barParams);

        setContentView(root);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AutoCycleManager.OnExpressionChange
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void onExpressionChange(int expression) {
        applyExpression(expression, false);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ExpressionApiServer.ExpressionListener
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void onExpressionCommand(int expression) {
        // Called from background thread — post to UI
        mUiHandler.post(() -> {
            mCycleManager.onApiOverride();
            mApiServer.setCurrentExpression(expression);
            applyExpression(expression, true);
            flashApiIndicator();
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internal
    // ─────────────────────────────────────────────────────────────────────────

    private void applyExpression(int expression, boolean fromApi) {
        mFaceView.setExpression(expression);
        mApiServer.setCurrentExpression(expression);

        String prefix = fromApi ? "⚡ API → " : "◆ ";
        mExpressionLabel.setText(prefix + ExpressionNameHelper.getLabel(expression));

        int color = expressionLabelColor(expression);
        mExpressionLabel.setTextColor(color);

        Log.i(TAG, (fromApi ? "[API] " : "[CYCLE] ") + ExpressionNameHelper.getName(expression));
    }

    private void flashApiIndicator() {
        mApiStatusDot.setTextColor(Color.parseColor("#f59e0b"));
        mApiStatusDot.setText("⚡ API");
        mApiFlashActive = true;
        mUiHandler.postDelayed(() -> {
            mApiStatusDot.setTextColor(Color.parseColor("#22c55e"));
            mApiStatusDot.setText("● API");
            mApiFlashActive = false;
        }, 1200);
    }

    private int expressionLabelColor(int expr) {
        switch (expr) {
            case FaceView.EXPRESSION_HAPPY:    return Color.parseColor("#22c55e");
            case FaceView.EXPRESSION_THINKING: return Color.parseColor("#a78bfa");
            case FaceView.EXPRESSION_ALERT:    return Color.parseColor("#f59e0b");
            case FaceView.EXPRESSION_ANGRY:    return Color.parseColor("#ef4444");
            default:                           return Color.parseColor("#3b82f6");
        }
    }

    private void refreshIpLabel() {
        String ip = getDeviceIpAddress();
        mIpLabel.setText(ip + ":" + ExpressionApiServer.PORT);
        mIpLabel.setTextColor(Color.parseColor("#6b7280"));
    }

    private String getDeviceIpAddress() {
        try {
            // Try WiFi manager first
            WifiManager wm = (WifiManager) getApplicationContext()
                    .getSystemService(WIFI_SERVICE);
            if (wm != null) {
                int ip = wm.getConnectionInfo().getIpAddress();
                if (ip != 0) return Formatter.formatIpAddress(ip);
            }
            // Fallback: enumerate interfaces
            List<NetworkInterface> interfaces =
                    Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : interfaces) {
                List<java.net.InetAddress> addrs = Collections.list(ni.getInetAddresses());
                for (java.net.InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress() && addr instanceof java.net.Inet4Address) {
                        return addr.getHostAddress();
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "IP lookup failed: " + e.getMessage());
        }
        return "?.?.?.?";
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density);
    }
}
