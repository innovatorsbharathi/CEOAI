package com.ceoai.face;

import android.os.Handler;
import android.os.Looper;

/**
 * CEO AI — Expression Auto-Cycle Manager
 *
 * Automatically cycles through expressions at a configurable interval.
 * Can be paused (e.g. when an API command arrives) and resumed after
 * a configurable delay.
 *
 * Default cycle order: NEUTRAL → HAPPY → THINKING → ALERT → ANGRY → repeat
 * Default interval  : 5 seconds per expression
 * Auto-resume delay : 15 seconds after an API override
 */
public class AutoCycleManager {

    public interface OnExpressionChange {
        void onExpressionChange(int expression);
    }

    // ── Config ────────────────────────────────────────────────────────────────
    private static final long DEFAULT_INTERVAL_MS     = 5_000L;
    private static final long API_OVERRIDE_RESUME_MS  = 15_000L;

    private final int[] CYCLE_ORDER = {
        FaceView.EXPRESSION_NEUTRAL,
        FaceView.EXPRESSION_HAPPY,
        FaceView.EXPRESSION_THINKING,
        FaceView.EXPRESSION_ALERT,
        FaceView.EXPRESSION_ANGRY,
    };

    // ── State ─────────────────────────────────────────────────────────────────
    private final Handler mHandler   = new Handler(Looper.getMainLooper());
    private int           mIndex     = 0;
    private boolean       mRunning   = false;
    private boolean       mPaused    = false;
    private long          mIntervalMs;
    private final OnExpressionChange mCallback;

    // ── Runnables ─────────────────────────────────────────────────────────────
    private final Runnable mCycleRunnable = new Runnable() {
        @Override public void run() {
            if (!mRunning || mPaused) return;
            int expr = CYCLE_ORDER[mIndex % CYCLE_ORDER.length];
            mCallback.onExpressionChange(expr);
            mIndex = (mIndex + 1) % CYCLE_ORDER.length;
            mHandler.postDelayed(this, mIntervalMs);
        }
    };

    private final Runnable mResumeRunnable = () -> {
        mPaused = false;
        mHandler.removeCallbacks(mCycleRunnable);
        mHandler.post(mCycleRunnable);
    };

    // ── Constructor ───────────────────────────────────────────────────────────

    public AutoCycleManager(OnExpressionChange callback) {
        this(callback, DEFAULT_INTERVAL_MS);
    }

    public AutoCycleManager(OnExpressionChange callback, long intervalMs) {
        mCallback   = callback;
        mIntervalMs = intervalMs;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public void start() {
        if (mRunning) return;
        mRunning = true;
        mPaused  = false;
        mHandler.postDelayed(mCycleRunnable, mIntervalMs);
    }

    public void stop() {
        mRunning = false;
        mHandler.removeCallbacks(mCycleRunnable);
        mHandler.removeCallbacks(mResumeRunnable);
    }

    /**
     * Called when an external API command arrives.
     * Pauses auto-cycle and schedules a resume after {@link #API_OVERRIDE_RESUME_MS}.
     */
    public void onApiOverride() {
        mPaused = true;
        mHandler.removeCallbacks(mCycleRunnable);
        mHandler.removeCallbacks(mResumeRunnable);
        mHandler.postDelayed(mResumeRunnable, API_OVERRIDE_RESUME_MS);
    }

    public void setIntervalMs(long ms) {
        mIntervalMs = ms;
    }

    public boolean isPaused()  { return mPaused;   }
    public boolean isRunning() { return mRunning;  }
}
