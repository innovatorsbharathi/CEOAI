# CEO AI — Robot Face App
### Geometric Expression Display for Android 9" Tablet

A full-screen, immersive facial expression renderer for the CEO AI robot head.  
Built in pure Android Java — no external libraries, no XML layouts, no internet required.

---

## 📁 Project Structure

```
ceoai-face/
├── app/src/main/
│   ├── AndroidManifest.xml
│   └── java/com/ceoai/face/
│       ├── MainActivity.java          ← Entry point, wires everything
│       ├── FaceView.java              ← Custom Canvas face renderer
│       ├── AutoCycleManager.java      ← Timed expression cycling
│       ├── ExpressionApiServer.java   ← Local HTTP API server (port 8765)
│       └── ExpressionNameHelper.java  ← Expression name utilities
├── app/build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🎭 Expressions

| Code | Name      | Visual Style                          | Status Bar |
|------|-----------|---------------------------------------|------------|
| 0    | NEUTRAL   | Flat eyes, flat line mouth, blue      | 65%        |
| 1    | HAPPY     | Arc eyes (^), wide smile arc, green   | 95%        |
| 2    | THINKING  | Raised/lowered brows, angled mouth, purple scan-line | 55% |
| 3    | ALERT     | Wide square eyes, pulsing glow, amber | 80%        |
| 4    | ANGRY     | Angled brows, frown arc, red          | 30%        |

All transitions are **smoothly animated** (600ms interpolated blend).  
Eyes **blink automatically** every ~4 seconds.  
A subtle **breathing oscillation** animates during idle.

---

## ⚙️ How to Build

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- A physical Android tablet (9") running Android 5.0+
- USB debugging enabled on the tablet

### Steps

```bash
# 1. Open project in Android Studio
File → Open → select the ceoai-face/ folder

# 2. Connect tablet via USB

# 3. Run
Run → Run 'app'   (or press Shift+F10)
```

The app will launch in **full-screen landscape mode** automatically.

---

## 🌐 HTTP API Reference

The app starts an HTTP server on **port 8765** when launched.  
The tablet's IP address is shown in the bottom-right corner of the display.

### Change Expression — `POST /expression`

```bash
curl -X POST http://<TABLET_IP>:8765/expression \
     -H "Content-Type: application/json" \
     -d '{"expression": "happy"}'
```

**Valid expression values:** `neutral` | `happy` | `thinking` | `alert` | `angry`

**Response:**
```json
{ "status": "ok", "expression": "happy" }
```

---

### Get Current Expression — `GET /expression`

```bash
curl http://<TABLET_IP>:8765/expression
```

**Response:**
```json
{ "expression": "neutral", "status": "ok" }
```

---

### Health Check — `GET /health`

```bash
curl http://<TABLET_IP>:8765/health
```

**Response:**
```json
{ "status": "ok", "agent": "CEO AI Face v1.0", "port": 8765 }
```

---

## 🔗 Integrating with CEO AI Brain (Python/Node example)

### Python
```python
import requests

TABLET_IP = "192.168.1.42"   # replace with your tablet's IP
BASE_URL  = f"http://{TABLET_IP}:8765"

def set_expression(name: str):
    """Set CEO AI robot face expression."""
    r = requests.post(f"{BASE_URL}/expression",
                      json={"expression": name}, timeout=3)
    return r.json()

# When CEO AI is processing a task:
set_expression("thinking")

# When a sale closes:
set_expression("happy")

# When an alert fires:
set_expression("alert")

# When a target is missed:
set_expression("angry")
```

### Node.js
```javascript
const TABLET = "http://192.168.1.42:8765";

async function setExpression(name) {
  const res = await fetch(`${TABLET}/expression`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ expression: name }),
  });
  return res.json();
}

await setExpression("alert");
```

---

## 🤖 Auto-Cycle Behaviour

- **Default**: cycles through all 5 expressions every **5 seconds**
- **On API command**: auto-cycle **pauses for 15 seconds**, then resumes
- The ⚡ indicator in the bottom bar flashes amber when an API command is received
- The ● API indicator stays green while the server is running

---

## 🖥️ Display Notes

- Optimised for **landscape 9" tablet** (1280×800 or 1920×1200)
- Screen stays **always on** (FLAG_KEEP_SCREEN_ON)
- Full immersive mode hides status bar and navigation bar
- Minimum Android version: **5.0 (API 21)**

---

## 🔧 Customisation

| What to change          | Where                          |
|-------------------------|--------------------------------|
| Cycle interval          | `AutoCycleManager.java` — `DEFAULT_INTERVAL_MS` |
| API resume delay        | `AutoCycleManager.java` — `API_OVERRIDE_RESUME_MS` |
| API port                | `ExpressionApiServer.java` — `PORT` |
| Colour palette          | `FaceView.java` — `COL_*` constants |
| Face proportions        | `FaceView.onDraw()` — `faceW`, `eyeGap`, `mouthY` multipliers |
| Cycle order             | `AutoCycleManager.java` — `CYCLE_ORDER` array |

---

*© 2026 CEO AI / Bharathiya Innovators Foundation — Kanjikode, Palakkad, Kerala*
